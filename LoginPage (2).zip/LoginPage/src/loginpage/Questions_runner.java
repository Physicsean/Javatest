/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loginpage;


import java.io.FileNotFoundException;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.scene.layout.*;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import java.math.*;
import javafx.scene.control.RadioButton;
import java.util.ArrayList;
import javafx.scene.control.ToggleGroup;
import java.util.Scanner;
import java.lang.Thread;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.util.Duration;

/**
 *
 * @author Sean
 */
public class Questions_runner extends Application   {
        int correct =0;
        int wrong = 0;
        int question = (int)(Math.random() * (1+100));
        int difficulty = question%25;
        String solution ="0";
        String User= " ";
        int minutes=10; 
        int seconds=0;
        String time;
    
        Thread click = new Thread();
         Button btn = new Button();
        Label timelabel= new Label();
    @Override
    public void start(Stage primaryStage) throws Exception {
        Button btn = new Button();
        btn.setText("Submit");
        
        Button Next = new Button();
        Next.setText("Next");
        
        Label l1 = new Label();
        Label l2 = new Label();
        Label l3 = new Label();
        Label l4 = new Label();
        Label l5 = new Label();
        Label Q = new Label();
        
        RadioButton r1 = new RadioButton();
        RadioButton r2 = new RadioButton();
        RadioButton r3 = new RadioButton();
        RadioButton r4 = new RadioButton();
        RadioButton r5 = new RadioButton();
        ToggleGroup choice = new ToggleGroup();
        r1.setToggleGroup(choice);
        r2.setToggleGroup(choice);
        r3.setToggleGroup(choice);
        r4.setToggleGroup(choice);
        r5.setToggleGroup(choice);
        
 

        java.io.File file = new java.io.File("Question"+question+".txt");
        Scanner in = new Scanner(file);
        
        
        Q.setText(in.nextLine());
        
        l1.setText(in.nextLine());
        l2.setText(in.nextLine());
        l3.setText(in.nextLine());
        l4.setText(in.nextLine());
        l5.setText(in.nextLine());
       
        solution = in.nextLine();
        
        in.close();
        
        VBox all = new VBox();
        all.getChildren().add(Q);
        
        
        GridPane root = new GridPane();
        root.add(r1,0,0);
        root.add(l1,1,0);
        root.add(r2,0,1);
        root.add(l2,1,1);
        root.add(r3,0,2);
        root.add(l3,1,2);
        root.add(r4,0,3);
        root.add(l4,1,3);
        root.add(r5,0,4);
        root.add(l5,1,4);
        root.add(Next,0,5);
        root.add(btn,2,5);
        root.add(timelabel,0,6);
        
        all.getChildren().add(root);
        
        Thread clock = new Thread(new Clock2());
        
        clock.start();
        System.out.println("Ran line 112");
        clock.run();
        System.out.println("ran line 113");
        
        EventHandler<ActionEvent> eventHandler = e ->
                        {
         String min;
         String sec;
        seconds -=1;
        if(seconds<0)
        {
            seconds +=59;
            minutes -=1;
        }
        if(seconds <=9)
        {
            sec ="0"+Integer.toString(seconds);
        }
        else
        {
            sec = Integer.toString(seconds);
        }
        if(minutes >=9)
        {
            min = "0"+Integer.toString(minutes);
        }
        else
        {
            min = Integer.toString(minutes);
        }
        if (minutes ==0 && seconds ==0)
        {
            btn.fire();
        }
        time = min +":"+sec;
        timelabel.setText(time);
                        };
                        
                        Timeline animation = new Timeline(
                        new KeyFrame( Duration.millis(1000) ,eventHandler));
                        animation.setCycleCount(600);
                        animation.play(); //this is the animation
        
       
        
        Scene qscene = new Scene(all, 400, 400);
        
        primaryStage.setTitle("Taking a test");
        primaryStage.setScene(qscene);
        primaryStage.show();
        
        btn.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event)
            {
                String res =scoretest(correct,wrong);
                try {
                    writes(res);
                    TestHome pretest = new TestHome();
                    pretest.passname(User);
                    pretest.start(primaryStage);
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(Questions_runner.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
                    
        });
        
        Next.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event)  {
                boolean c;
                String answer="1";
                if(r1.isSelected())
                    answer ="1";
                else if(r2.isSelected())
                    answer="2";
                else if(r3.isSelected())
                    answer="3";
                else if(r4.isSelected())
                    answer ="4";
                else if(r5.isSelected())
                    answer ="5";
                if (answer.equals(solution))
                {
                    System.out.println("Correct");
                    correct+=1;
                    difficulty +=1;
                    if (difficulty>4)
                    {
                        difficulty =4;
                    }
                }
                else
                {
                    System.out.println("Wrong");
                    wrong +=1;
                    difficulty -=1;
                    if(difficulty <0)
                    {
                        difficulty =0;
                    }
                }
                if (correct +wrong == 20)
                {
                    String result = scoretest(correct,wrong);
                    try {
                        writes(result);
                        TestHome pretest = new TestHome();
                        pretest.passname(User);
                        pretest.start(primaryStage);
                    } catch (FileNotFoundException ex) {
                        Logger.getLogger(Questions_runner.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                
    /////////////////////////////////////////////////////////////////////////////////////////////////////
                //Generate a new question
                int diffmod= difficulty*20;
                question = (int)((Math.random()* (20))  + diffmod);
                
                //Would for some reason give question hundereds bigger than nesccasary. This catches that problem
                //base 10 values still fit difficulty settings
                while(question >=101)
                {
                    question -=100;
                    //System.out.println(question);
                }
                System.out.println(question);
                java.io.File file1 = new java.io.File("Question"+question+".txt");
                try {
                Scanner inn = new Scanner(file1);
                Q.setText(inn.nextLine());
                l1.setText(inn.nextLine());
                l2.setText(inn.nextLine());
                l3.setText(inn.nextLine());
                l4.setText(inn.nextLine());
                l5.setText(inn.nextLine());
                solution = inn.nextLine();
                in.close();
                     
                    
                }catch (Exception ex) {
                    Logger.getLogger(Questions_runner.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        });
 ///////////////////////////////////////////////////////////////////////////////////////////////////       
        
}
    
public String scoretest(int correct, int wrong)
{
         double aa;
         double bb;
         double cc;
         double ee;
         double ff;
                    
          aa= (correct -wrong)/20;
          bb = 1-aa;
         cc = bb * wrong;
         ee = cc+ bb;
         ff = correct*5 - ee;
         System.out.println(correct +" "+ wrong);
          System.out.println(ee);
          //ee = 100;
          if(ee>=85)
          {
              return "Java Certified Architect";
          }
          else if(ee<75 && ee>85)
          {
              return "Java Certified Developer";
          }
          else if (ee<65 && ee>85)
          {
              return "Java Certified Programmer";
          }
          else
          {
              return "You failed-try again";
          }
          
           
}

    public void tester(String name)
    {
        User= name;
    }
    /**
     * @param args the command line arguments
     */
    public void writes(String result) throws FileNotFoundException
    {
        int attempts;
                java.io.File file = new java.io.File(User+".txt");
                    if(file.exists())
                    {
                        Scanner in = new Scanner(file);
                        String id = in.nextLine();
                        attempts= in.nextInt();
                        attempts +=1;
                        
                
            try (java.io.PrintWriter out = new java.io.PrintWriter(file)) {
                out.println(id);
                out.println(attempts);
                out.println(result);
            }
                    }

                    
    }
    
    public void timekeep(int minutes, int seconds)
    {
         String min;
         String sec;
        seconds -=1;
        if(seconds<0)
        {
            seconds +=59;
            minutes -=1;
        }
        if(seconds <=9)
        {
            sec ="0"+Integer.toString(seconds);
        }
        else
        {
            sec = Integer.toString(seconds);
        }
        if(minutes >=9)
        {
            min = "0"+Integer.toString(minutes);
        }
        else
        {
            min = Integer.toString(minutes);
        }
        if (minutes ==0 && seconds ==0)
        {
            btn.fire();
        }
        time = min +":"+sec;
        timelabel.setText(time);
    }
    
    /*
    public static void main(String[] args) {
        launch(args);
    }  
 */   
}
