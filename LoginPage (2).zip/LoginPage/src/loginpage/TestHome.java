/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loginpage;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.input.KeyEvent;

/**
 *
 * @author Sean
 */
public class TestHome extends Application {
    String User=" ";
    int att=0;
    @Override
    public void start(Stage primaryStage) throws FileNotFoundException {
        Button exitbtn = new Button();
        Button taketest = new Button();
        Label attempts = new Label("Attempts");
        Label title = new Label("Title from a set title");
        Label welcome= new Label("Welcome "+ User+" \n You will have 10 minutes to answer 20 questions. \n You may quit the test at any time by pressing submit. \n If you are unhappy with your score \n you may take the test up to one additional time. \n Press enter or TakeTest to start the test.");
        
        
        java.io.File file = new java.io.File(User+".txt");
                    if(file.exists())
                    {
                        Scanner in = new Scanner(file);
                        String id = in.nextLine();
                        att = in.nextInt();
                        String tit = in.nextLine();
                        String tit1 = in.nextLine();
                        attempts.setText("You have attempte the test "+ Integer.toString(att)+" times" );
                        title.setText("Test Result: "+tit1);
                        
                        System.out.println(tit);
                        System.out.println(tit1);
                        System.out.println(att);
                    }
                    System.out.println(att);
        
        VBox home = new VBox();
        VBox top = new VBox();
        HBox bot = new HBox();
        
        

        
        exitbtn.setText("Logout'");
        taketest.setText("Take Test");
        
        
        
        
        
        taketest.setOnAction(new EventHandler<ActionEvent>() {   
            @Override
            public void handle(ActionEvent event) {
                if (att<2)
            {
                System.out.println("Take test application");
               
                Questions_runner test = new Questions_runner();
                test.tester(User);
                try {
                    test.start(primaryStage);
                } catch (Exception ex) {
                    Logger.getLogger(TestHome.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
                else
                {
                    System.out.println("2 many attempts");
                
            }
            }
        });

        exitbtn.setOnAction((ActionEvent event) -> {
            LoginPage logs = new LoginPage();
            try { 
                logs.start(primaryStage);
            } catch (IOException ex) {
                Logger.getLogger(TestHome.class.getName()).log(Level.SEVERE, null, ex);
            }
            System.out.println("Logout");
        });
        
        if (att>=2)
        {
            taketest.disarm();// can't take test more than twice
            //System.out.print("Test is disarmed");
        }
             
        top.getChildren().add(welcome);
        top.getChildren().add(attempts);
        top.getChildren().add(title);
        
        bot.getChildren().add(taketest);
        bot.getChildren().add(exitbtn);
        
        home.getChildren().add(top);
        home.getChildren().add(bot);
        
        Scene scene = new Scene(home, 500, 500);
        
        primaryStage.setTitle("Home Page!");
        primaryStage.setScene(scene);
        primaryStage.show();
        
        home.setOnKeyPressed(e -> {
            switch(e.getCode())
            {
                case ENTER:
                {
                    taketest.fire();
                }
                default:
                {
                    System.out.println("Stop pressing keys");
                }
            }
            });
    }
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    public void passname(String name)
    {
        User = name;
    }
    
    

}
