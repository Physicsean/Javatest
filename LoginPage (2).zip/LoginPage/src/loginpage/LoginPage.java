/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loginpage;


import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.scene.text.Text;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import java.io.PrintWriter;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import static javafx.application.Application.launch;
import javafx.geometry.Pos;
import javafx.scene.control.PasswordField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;


/**
 *
 * @author Sean
 */
public class LoginPage extends Application  {
    
    Scene loginpage;
    Scene testpage;
    Scene home;
    
    
    @Override
    public void start(Stage primaryStage) throws java.io.IOException {
       
        
  
        /////////////////////////////////////////////////////////////////////////
        
        
        TextField question= new TextField();
        PasswordField choice1 = new PasswordField();
      
        Label notes = new Label();
        
        Button Sign = new Button();
        Sign.setText("Login");
        
        Button clear = new Button();
        clear.setText("Exit");
        
        Label label1 = new Label("Name: ");
        Label label2 = new Label("ID: ");
      
        GridPane pane = new GridPane();
        pane.add(label1,0,0);
        pane.add(question, 1,0);
        
        pane.add(label2,0,1);
        pane.add(choice1,1,1);
  
        pane.add(Sign, 0,7);
        pane.add(clear,1,7);
        
        pane.add(notes,1,8);
        
        Scene LPage = new Scene(pane,400,400);
        primaryStage.setTitle("Login Page");
        primaryStage.setScene(LPage);
        primaryStage.show();
        
        Clock2 click = new Clock2();
        
              
        Sign.setText("Login");
        
        Sign.setOnAction(new EventHandler<ActionEvent>()  {
            
            @Override
            public void handle(ActionEvent event  )   {
                try {
                    String q = question.getText();
                    String a = choice1.getText();
                    
                    java.io.File file = new java.io.File(q+".txt");
                    if(file.exists())
                    {
                        Scanner in = new Scanner(file);
                        String id = in.nextLine();
                        System.out.println(a+".");
                        System.out.println(id+".");
                        if(id.equals(a))
                        {
                            in.close();
                            System.out.println("You have successfully logged in");
                            TestHome pretest = new TestHome();
                            pretest.passname(q);
                            pretest.start(primaryStage);
                            //
                            
                           //primaryStage.setScene();
                        }
                        else
                        {
                            
                            System.out.println("That is the wrong ID. Please Try Again");
                            notes.setText("Failed to login, try again");
                        }
                    }
                    else
                        {
                            writes(q,a);
                            System.out.println("An account named "+ q + " has been created");
                            notes.setText("An account has been created with your username and password");
                        }
                           
                    question.setText("");
                    choice1.setText("");

                } catch (IOException ex) {
                    Logger.getLogger(LoginPage.class.getName()).log(Level.SEVERE, null, ex);
                }
                      
            }
        });
       
        clear.setOnAction(new EventHandler<ActionEvent>()  {
            
            @Override
            public void handle(ActionEvent event) {
                final Stage dialogStage = new Stage();
                dialogStage.initModality(Modality.WINDOW_MODAL);

                Label exitLabel = new Label("Are you sure you want to exit?");
                exitLabel.setAlignment(Pos.BASELINE_CENTER);

                Button yesBtn = new Button("Yes");
                yesBtn.setOnAction(new EventHandler<ActionEvent>() {

                    @Override
                    public void handle(ActionEvent arg0) {
                        dialogStage.close();
                        primaryStage.close();

                    }
                });
                Button noBtn = new Button("No");

                noBtn.setOnAction(new EventHandler<ActionEvent>() {

                    @Override
                    public void handle(ActionEvent arg0) {
                        dialogStage.close();

                    }
                });

                HBox hBox = new HBox();
                hBox.setAlignment(Pos.BASELINE_CENTER);
                hBox.setSpacing(40.0);
                hBox.getChildren().addAll(yesBtn, noBtn);

                VBox vBox = new VBox();
                vBox.setSpacing(40.0);
                vBox.getChildren().addAll(exitLabel, hBox);

                dialogStage.setScene(new Scene(vBox));
                dialogStage.show();
            }
        });

    }
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    
    
    
    
 /////////////////////////////////////////////////////////////////////////////////////////////////////////////////   
    
    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws java.io.IOException {
        launch(args);
    }
    
    public void writes(String N,String I) throws java.io.IOException {
        
                java.io.File file = new java.io.File(N+".txt" );
                java.io.PrintWriter out = new java.io.PrintWriter(file);
                out.println(I);
                out.println(0);
                String t= "No title";
                out.println(t);
                out.close();
                
    
}
    
}
