/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loginpage;

/**
 *
 * @author Sean
 */
import java.util.*;
import java.awt.*;
import java.applet.*;

public class Clock2 extends Applet implements Runnable {
    Graphics g;
    Font font;
    Thread my_thread;
    int width, height;
    Calendar current_time;
    String time = " ";
    
    public void init()
    {
        g = getGraphics();
        current_time = Calendar.getInstance();
        set_defaults();
    }
    
    void set_defaults()
    {
        width = 200;
        height = 30;
        resize(width,height);
        font = new Font("Courier",Font.BOLD, 48);
        g.setFont(font);
    }
    
    public void start()
    {
        if (my_thread == null)
        {
            my_thread = new Thread(this);
            my_thread.start();
        }
    }
    
    public void stop()
    {
        my_thread = null;
    }
    
    public void run()
    {
        System.out.println("Clock has started");
        while (my_thread != null)
        {
            repaint();
            try{
                System.out.println("In try loop of run");
                Thread.sleep(1000);
                
            }
            catch (InterruptedException e)
            {
                System.out.println("System Interrupted");
            }
        }
        System.out.println("Finished running");
    }
    public void update (Graphics g)
    {
        g.setPaintMode();
        current_time = Calendar.getInstance();
        int hours = current_time.get(Calendar.HOUR);
        int minutes = current_time.get(Calendar.MINUTE);
        int seconds = current_time.get(Calendar.SECOND);
        String prev_time = time;
        if(hours < 10)
            time = "0" + hours;
        else
                    time = ""+ hours;
        if(minutes < 10)
            time = ":0" + minutes;
        else
                    time = ":"+ minutes;
        if(seconds < 10)
            time = ":0" + seconds;
        else
                    time = ":"+ seconds;
        g.setColor(Color.white);
        g.setFont(font);
        g.drawString(prev_time,100,height+175);
        g.setColor(Color.blue);
        g.drawString(time, 100, height+175);
        System.out.println("Time is: "+time);
    }
    public void paint()
    {
        set_defaults();
        update(g);
        System.out.println("Time isnt: "+time);
        
    }
    
}
